### Node.js in Practice

The source code for the book [Node.js in Practice](http://manning.com/young/) (ISBN: 9781617290930).
