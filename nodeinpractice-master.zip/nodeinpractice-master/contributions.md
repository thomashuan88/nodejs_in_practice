### Contributions from readers

* Connor Ameres: Fix for Listing 2.14 in `listings/globals/arguments.js`
