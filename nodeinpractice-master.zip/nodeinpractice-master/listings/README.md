## Node.js in Practice

### Source Code

This folder contains all of the examples from the book.

The code has been written according to the [Google JavaScript Style Guide](http://google-styleguide.googlecode.com/svn/trunk/javascriptguide.xml), in the hope that this provides a neutral style that readers will find easy to follow.

Thanks for reading,

Alex and Marc
