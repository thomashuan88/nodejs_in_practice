var a = 0

function changeA () {
  a = 50
}

function addToA (toAdd) {
  a += toAdd
}

changeA()
addToA(25)
addToA(25)
