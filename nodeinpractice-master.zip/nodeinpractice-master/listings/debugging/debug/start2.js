var a = 0

function changeA () {
  debugger
  a = 100
}

function addToA (toAdd) {
  a += toAdd
}

changeA()
addToA(25)
addToA(25)
