var request = require('request')

request('http://adc4gis.com', function (er, res, body) {
  console.log('made it johnny')
})
