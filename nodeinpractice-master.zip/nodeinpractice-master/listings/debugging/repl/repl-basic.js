var repl = require('repl')

repl.start({
  input: process.stdin,
  output: process.stdout
})
