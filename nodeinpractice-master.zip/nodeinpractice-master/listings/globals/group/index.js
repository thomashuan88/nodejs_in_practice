module.exports = { //<co id="callout-globals-modules-group-1" />
  one: require('./one'),
  two: require('./two')
};
