module.exports = function() {
  console.log('one');
};
