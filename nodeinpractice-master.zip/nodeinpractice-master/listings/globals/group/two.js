module.exports = function() {
  console.log('two');
};
