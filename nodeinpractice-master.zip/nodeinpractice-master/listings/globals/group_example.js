var group = require('./group'); //<co id="callout-globals-modules-group-load" />

group.one();
group.two();
