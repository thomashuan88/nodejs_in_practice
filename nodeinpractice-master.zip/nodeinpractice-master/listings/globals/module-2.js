exports.method = function() {
  return 'Hello';
};

exports.method2 = function() {
  return 'Hello again';
};
