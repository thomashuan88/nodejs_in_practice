var myClass = require('./myclass'); //<co id="callout-globals-modules-require-1" />
var module2 = require('./module-2'); //<co id="callout-globals-modules-require-2" />


console.log(myClass.method());
console.log(module2.method());
console.log(module2.method2());
