console.log('__dirname:', __dirname); //<co id="callout-globals-paths" />
console.log('__filename:', __filename);
