if (!value) {
  var value = {}; // <co id="bad-scope_1" />
}
