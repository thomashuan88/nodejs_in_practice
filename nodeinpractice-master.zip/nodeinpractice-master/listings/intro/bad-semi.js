function createUser() {
  return // <co id="bad-semi_1" />
  {
    name: 'alex'
  }
}

console.log(createUser());
