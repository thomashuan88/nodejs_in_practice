'' === '0'           // false <co id="equality-strict_1" />
0 === ''             // false
0 === '0'            // false

false === undefined  // false
false === null       // false
null === undefined   // false
