'' == '0'           // false <co id="equality_1" />
0 == ''             // true
0 == '0'            // true

false == undefined  // false
false == null       // false
null == undefined   // true
