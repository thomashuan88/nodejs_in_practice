if (s.value === null || s.value === undefined) {
