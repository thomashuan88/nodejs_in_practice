if (s.value == null) {
