var assert = require('assert');

function square(a) {
  return a * a;
}

assert.equal(square(4), 16); //<co id="callout-testing-travis-test-1" />
