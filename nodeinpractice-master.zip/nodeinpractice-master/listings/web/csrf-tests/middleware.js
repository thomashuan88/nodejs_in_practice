var express = require('express');

module.exports.csrf = express.csrf; //<co id="callout-web-testing-seams-1-1"/>
