var app = require('./app');
app.listen(process.env.NODE_ENV || 3000);
