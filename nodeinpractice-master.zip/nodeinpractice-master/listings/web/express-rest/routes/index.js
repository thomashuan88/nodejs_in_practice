module.exports = {
  pages: require('./pages')
};
