var connect = require('connect');

connect.createServer( //<co id="callout-quick-connect-1" />
  connect.static(__dirname) //<co id="callout-quick-connect-2" />
).listen(8080); //<co id="callout-quick-connect-3" />
